﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArreglosBidimensionales
{
        internal class GradeBook
        {
            //atributos de la clase
            private int[,] grades; //arreglo con la calificaciones
            private string courseName; //nombre del curso

            //propiedades para acceder a los atributos
            public String CourseName
            {
                get { return courseName; }
            }

            //Constructor para pasar los valores iniciales que 
            //necesita la clase
            public GradeBook(int[,] grades, string courseName)
            {
                this.grades = grades;
                this.courseName = courseName;
            }

            //Metodo para mostrar el nombre del curso
            public void DisplayCourse()
            {
                Console.WriteLine($"Bienvenido al curso de {courseName}\n");
            }

            //Metodo para buscar la calificacion mas baja
            public int getMinimun()
            {
                int minimun = grades[0, 0];

                foreach (var grade in grades)
                {
                    if (grade < minimun)
                    {
                        minimun = grade;
                    }
                }
                return minimun;
            }

            //Metodo para buscar la calificacion mas alta
            public int getMaximun()
            {
                int maximun = grades[0, 0];

                foreach (var grade in grades)
                {
                    if (grade > maximun)
                    {
                        maximun = grade;
                    }
                }
                return maximun;
            }

            //Metodo para determinar el promedio de la clase
            public double getAverage()
            {
                double total = 0;

                foreach (var grade in grades)
                {
                    total += grade;
                }
                return total / grades.Length;
            }

        //Metodo para determinar el promedio de un estudiante
        public double getStudentAverage(int student)
        {
            //obtener cuantas calificaciones tiene un estudiante
            var studentGradeCount = grades.GetLength(1);
            var total = 0.0;

            //suma todas las calificaciones para ese estudiante
            for(int grade = 0; grade < studentGradeCount;grade++)
            {
                total += grades[student, grade];
            }
            return total / studentGradeCount;
        }

        //Metodo para mostrar la distribucion de calificaciones
        
        public void showDistribution()
            {
                Console.WriteLine("La Distribución de Calificaciones es: \n");

                //declarar un arreglo auxiliar para almacenar las
                //cantidades de calificaciones por rango
                var frecuency = new int[11];

                foreach (var grade in grades)
                {
                    ++frecuency[grade / 10];
                }

                //imprimir un grafico
                for (int i = 0; i < frecuency.Length; ++i)
                {
                    //imprimir una etiqueta con los rangos
                    if (i == 10)
                    {
                        Console.Write("  100: ");
                    }
                    else
                    {
                        Console.Write($"{i * 10:D2}-{i * 10 + 9:D2}: ");
                    }

                    for (int asteric = 0; asteric < frecuency[i]; ++asteric)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine(); //salte a la otra linea
                }
            }

            //Metodo que muestre las calificaciones de los estudiantes
            public void ShowGrades()
            {
              
            }

            //Metodo para procesar toda la informacion
            public void ProcessGrades()
            {
                //Muestra el nombre del curso
                DisplayCourse();
                //Muestra las calificaciones
                ShowGrades();
                //Muestra el promedio de la clase
                Console.WriteLine($"El promedio de la clase es {getAverage()}");
                //Mostrar el valor mas pequeño
                Console.WriteLine($"La calificacion más baja es {getMinimun()}");
                Console.WriteLine($"La calificacion mas alta es {getMaximun()}");
                //Muestra la distribucion de calificaciones
                showDistribution();
            }
        }
    }


