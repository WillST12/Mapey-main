﻿namespace ArreglosUnidimensionales
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //usted tiene una clase con 10 estudiantes, donde
            //cada uno tiene una calificación a ser introducida
            //por el usuario.
            //Se desea mostrar el nombre del curso, las califi-
            //caciones por estudiante, el promedio, la mas alta,
            //la mas baja y una distribución de las calificaciones



            //Pedimos el nombre del curso
            string courseName;
            Console.WriteLine("Introduzca el nombre del Curso: ");
            courseName = Console.ReadLine();

            int[] grades = new int[10];

            //pedir las calificaciones

            for (int i = 0; i < grades.Length; i++)
            {
                Console.Write($"Introduzca la calificacion del estudiante {i + 1}: ");
                grades[i] = Convert.ToInt32( Console.ReadLine() );
            }

            //Instanciar la clase GradeBook
            GradeBook gr1 = new GradeBook(grades, courseName);

            gr1.ProcessGrades();
        }
    }
}