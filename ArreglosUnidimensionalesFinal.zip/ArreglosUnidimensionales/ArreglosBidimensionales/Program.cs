﻿namespace ArreglosBidimensionales
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Tenemos 10 estudiantes y cada estudiante tiene 3
            //calificaciones
            int[,] grades =
            {
                {70, 87, 93 },
                {85, 89, 100},
                {90, 90, 78 },
            };
        }
    }
}