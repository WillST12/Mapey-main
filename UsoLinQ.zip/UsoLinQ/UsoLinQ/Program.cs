﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsoLinQ
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var values = new[] { 12, 45, 18, 21, 14, 25, 16, 12, 28 };

            //Imprimir el arreglo original
            Console.WriteLine("Arreglo Original");
            foreach (var value  in values)
            {
                Console.Write($"{value} ");
            }
            Console.WriteLine();

            //seleccionar los adolescentes
            var adolescentes = from value in values
                               where value <= 19
                               select value;

            //Imprimir el arreglo de adolescentes
            Console.WriteLine("Adolescentes");
            foreach (var value in adolescentes)
            {
                Console.Write($"{value} ");
            }
            Console.WriteLine();

            //Ordenar el arreglo original
            var ordenado = from value in values
                           orderby value //descending or ascendig
                           select value;

            //Imprimir el arreglo original ordenado
            Console.WriteLine("Arreglo Ordenado");
            foreach (var value in ordenado)
            {
                Console.Write($"{value} ");
            }
            Console.WriteLine();

            //Seleccionar los adolescentes y ordenarlos
            var adolescentesOrdenados = from value in values
                                        where value <= 19
                                        orderby value
                                        select value;

            //Imprimir el arreglo ordenado
            Console.WriteLine("Adolescentes Ordenadoa");
            foreach (var value in adolescentesOrdenados)
            {
                Console.Write($"{value} ");
            }
            Console.WriteLine();

            List<string> items = new List<string>();

            items.Add("aQua");
            items.Add("rEd");
            items.Add("RusT");
            items.Add("yElLow");

            //convertir todos los elementos a mayusculas, seleccionar
            //solo los que empiezan con la letra R y ordenarlos
            var resultado = from value in items
                            let upperCaseString = value.ToUpper()
                            where upperCaseString.StartsWith("R")
                            orderby upperCaseString
                            select upperCaseString;


            //imprimimos el resultado
            foreach (var item in resultado)
            {
                Console.Write($"{item} ");
            }
            Console.WriteLine();

            /*Cree una clase llamada Empleado
             * Cada empleado tiene un nombre, un apellido y un salario
             * Usted le va a pedir al usuario ingresar informacion para
             * 10 empleados
             * Usando LinQ:
             * Imprimir una tabla de los empleados que tienen salarios
             * entre 4000 y 6000
             * Imprimir solo los salarios entre 4000 y 6000
             * Ordenar y mostrar los empleados por apellido, nombres
             * Mostrar solo el primer empleado del listado anterior (hint:First)
             * Mostrar solo los apellidos de los empleados (sin ordenar)
             * Si hubiesen apellidos repetidos, mostrar solo apellidos unicos.
             */


        }
    }
}
