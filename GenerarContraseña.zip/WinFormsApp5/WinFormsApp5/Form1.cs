using System.Text;

namespace WinFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                GeneradorContrase�a(6);
            }
            else if (radioButton2.Checked)
            {
                GeneradorContrase�a(10);
            }
            else if (radioButton3.Checked)
            {
                GeneradorContrase�a(12);
            }
            else
            {
                GeneradorContrase�a(8);
            }

        }
        public void GeneradorContrase�a(int len)
        {
            const string Face = "abcdefghijklmn�opqrstuvwxyzABCDEFGHIJKLMN�OPQRSTUVWXYZ0123456789";
            StringBuilder resultado = new StringBuilder();
            Random random = new Random();
            while (0 < len--)
            {
                resultado.Append(Face[random.Next(Face.Length)]);
            }
            textBox1.Text = resultado.ToString();
        }
    }
}